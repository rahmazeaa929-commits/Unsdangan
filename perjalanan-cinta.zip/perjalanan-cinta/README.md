# Perjalanan Cinta — Awang & Rahma

Video Remotion 9:16 (1080x1920, 30 fps). Urutan adegan sesuai konsep asli.

## Cara render (GitHub Actions)
1. Upload seluruh isi folder ini ke repo GitHub.
2. Buka tab **Actions** > **Render Perjalanan Cinta** > **Run workflow**.
3. Setelah selesai, unduh `perjalanan-cinta` dari bagian **Artifacts**.

## Yang bisa diubah
- **Durasi adegan**: `src/timeline.tsx` (angka `sec(...)`).
- **Teks judul/keterangan**: `src/timeline.tsx` dan `src/scenes.tsx`.
- **Posisi pin dan jalur di peta**: `src/config.ts` (koordinat persen).
- **Musik**: taruh `music.mp3` di folder `public/`, lalu isi `MUSIC_FILE = "music.mp3"` di `src/config.ts`.
- **Tampilan undangan**: taruh `undangan.jpg` (tangkapan layar undangan) di `public/`, lalu isi `UNDANGAN_FILE = "undangan.jpg"` di `src/config.ts`.

## Aset
- `public/maps/` peta Gemini, `public/photos/` foto (tampil utuh, tidak dipotong),
  `public/chars/` karakter tanpa latar, `public/video/bukit.mp4` klip senja di Makkah.
