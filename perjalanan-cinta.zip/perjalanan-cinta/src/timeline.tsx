import React from "react";
import { OVERLAP, PHOTO, sec } from "./config";
import {
  SceneBogorHome,
  SceneBogorPin,
  SceneBukitVideo,
  SceneGlobe,
  SceneGlobeHome,
  SceneGlobeToMakkah,
  SceneIndoRoute,
  SceneIndonesiaZoom,
  SceneJatim,
  SceneMakkahMap,
  ScenePhoto,
  SceneProbolinggo,
  SceneResepsi,
  SceneUndangan,
} from "./scenes";

export type SceneDef = { name: string; dur: number; el: React.ReactNode };

// Urutan = urutan cerita. Ubah angka sec(...) untuk mengatur durasi tiap adegan.
export const SCENES: SceneDef[] = [
  // 1. Awal cerita: Probolinggo
  { name: "globe", dur: sec(5), el: <SceneGlobe /> },
  { name: "indonesia-zoom", dur: sec(4), el: <SceneIndonesiaZoom /> },
  { name: "probolinggo", dur: sec(5), el: <SceneProbolinggo /> },
  // 2. Menuju Bogor
  {
    name: "ke-bogor",
    dur: sec(7),
    el: <SceneIndoRoute toBogor pair={false} title="Perjalanan ke Bogor" sub="Dari Probolinggo menuju Desa Cisarua" />,
  },
  {
    name: "bogor",
    dur: sec(5),
    el: <SceneBogorPin pair={false} title="Bogor" sub="Desa Cisarua, Kec. Nanggung, Kab. Bogor" />,
  },
  // 3. Pertunangan
  { name: "tunangan-1", dur: sec(5), el: <ScenePhoto photo={PHOTO.tunanganBerdua} banner title="Satu Langkah Lebih Dekat" /> },
  { name: "tunangan-2", dur: sec(4.5), el: <ScenePhoto photo={PHOTO.tunanganCincinDuduk} banner title="Cincin Sudah di Jari" sub="Senyumnya tidak bisa disembunyikan" /> },
  { name: "tunangan-3", dur: sec(5), el: <ScenePhoto photo={PHOTO.tunanganPasangCincin} banner title="Momen Pemasangan Cincin" /> },
  { name: "tunangan-4", dur: sec(5), el: <ScenePhoto photo={PHOTO.tunanganKeluarga} banner zoom={false} title="Bersama Keluarga Tercinta" /> },
  // 4. Menuju Makkah
  { name: "globe-makkah", dur: sec(8), el: <SceneGlobeToMakkah /> },
  // 5. Akad nikah di Makkah
  { name: "makkah-peta", dur: sec(5), el: <SceneMakkahMap /> },
  { name: "makkah-berdua", dur: sec(4.5), el: <ScenePhoto photo={PHOTO.makkahBerdua} title="Di Hadapan Ka'bah" /> },
  { name: "akad", dur: sec(6), el: <ScenePhoto photo={PHOTO.akad} title="Akad Nikah" sub="Masjidil Haram, Makkah" /> },
  { name: "makkah-rombongan", dur: sec(4.5), el: <ScenePhoto photo={PHOTO.makkahRombongan} zoom={false} title="Bersama Rombongan" /> },
  { name: "bukit-video", dur: sec(9.5), el: <SceneBukitVideo /> },
  // 6. Kembali ke Bogor
  { name: "globe-pulang", dur: sec(6), el: <SceneGlobeHome /> },
  { name: "bogor-pulang", dur: sec(4), el: <SceneBogorHome /> },
  // 7. Perjalanan mengajar
  {
    name: "ke-probolinggo",
    dur: sec(6),
    el: <SceneIndoRoute toBogor={false} pair title="Perjalanan Mengajar" sub="Dari Bogor menuju Probolinggo" />,
  },
  { name: "jatim", dur: sec(6.5), el: <SceneJatim /> },
  // 8. Kembali ke Bogor
  {
    name: "pulang-bogor",
    dur: sec(5),
    el: <SceneIndoRoute toBogor pair title="Kembali ke Bogor" sub="Selesai mengajar, pulang ke Desa Cisarua" />,
  },
  {
    name: "bogor-akhir",
    dur: sec(4),
    el: <SceneBogorPin pair title="Desa Cisarua" sub="Kecamatan Nanggung, Kabupaten Bogor" />,
  },
  // 9. Resepsi
  { name: "resepsi", dur: sec(7), el: <SceneResepsi /> },
  // 10. Transisi ke undangan
  { name: "undangan", dur: sec(6), el: <SceneUndangan /> },
];

export const TOTAL_FRAMES = SCENES.reduce((n, s) => n + s.dur, 0) - (SCENES.length - 1) * OVERLAP;
