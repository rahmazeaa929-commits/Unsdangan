import React from "react";
import {
  AbsoluteFill,
  Easing,
  Img,
  Sequence,
  interpolate,
  random,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { loadFont as loadPlayfair } from "@remotion/google-fonts/PlayfairDisplay";
import { loadFont as loadPoppins } from "@remotion/google-fonts/Poppins";
import { CREAM, GOLD, H, OVERLAP, Pt, W } from "../config";

const playfair = loadPlayfair("normal", { weights: ["600"], subsets: ["latin"] });
const poppins = loadPoppins("normal", { weights: ["400", "600"], subsets: ["latin"] });
export const SERIF = playfair.fontFamily;
export const SANS = poppins.fontFamily;

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
const ease = Easing.inOut(Easing.cubic);

/* ---------- Konteks adegan (durasi + fade-in) ---------- */
const SceneCtx = React.createContext({ dur: 1 });
export const useScene = () => React.useContext(SceneCtx);

const FadeIn: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [0, OVERLAP], [0, 1], clamp);
  return <AbsoluteFill style={{ opacity: o }}>{children}</AbsoluteFill>;
};

export const Scene: React.FC<{ from: number; dur: number; children: React.ReactNode }> = ({
  from,
  dur,
  children,
}) => (
  <Sequence from={from} durationInFrames={dur}>
    <SceneCtx.Provider value={{ dur }}>
      <FadeIn>{children}</FadeIn>
    </SceneCtx.Provider>
  </Sequence>
);

/* ---------- Kamera peta ---------- */
export type Cam = { t: number; scale: number; cx: number; cy: number };

function camAt(cams: Cam[], p: number): Cam {
  if (p <= cams[0].t) return cams[0];
  for (let i = 0; i < cams.length - 1; i++) {
    const a = cams[i];
    const b = cams[i + 1];
    if (p <= b.t) {
      const q = ease((p - a.t) / (b.t - a.t));
      return {
        t: p,
        scale: a.scale * Math.pow(b.scale / a.scale, q),
        cx: a.cx + (b.cx - a.cx) * q,
        cy: a.cy + (b.cy - a.cy) * q,
      };
    }
  }
  return cams[cams.length - 1];
}

export const MapView: React.FC<{
  src: string;
  cams: Cam[];
  children?: (s: { scale: number; p: number; frame: number }) => React.ReactNode;
}> = ({ src, cams, children }) => {
  const frame = useCurrentFrame();
  const { dur } = useScene();
  const p = Math.min(1, Math.max(0, frame / Math.max(1, dur - 1)));
  const c = camAt(cams, p);
  const tx = W / 2 - c.cx * W * c.scale;
  const ty = H / 2 - c.cy * H * c.scale;
  return (
    <AbsoluteFill style={{ background: "#1a0f06", overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          left: 0,
          top: 0,
          width: W,
          height: H,
          transformOrigin: "0 0",
          transform: `translate(${tx}px, ${ty}px) scale(${c.scale})`,
        }}
      >
        <Img src={staticFile(src)} style={{ width: W, height: H, objectFit: "cover" }} />
        {children?.({ scale: c.scale, p, frame })}
      </div>
    </AbsoluteFill>
  );
};

/* ---------- Pin + label ---------- */
export const MapPin: React.FC<{
  at: Pt;
  scale: number;
  label?: string;
  sub?: string;
  delay?: number;
  showPin?: boolean;
  dy?: number; // geser ke atas (px layar)
}> = ({ at, scale, label, sub, delay = 0, showPin = true, dy = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame: frame - delay, fps, config: { damping: 12, stiffness: 120 } });
  const pulse = (frame % 60) / 60;
  return (
    <div
      style={{
        position: "absolute",
        left: (at.x * W) / 100,
        top: (at.y * H) / 100,
        transform: `translate(-50%, -100%) translate(0px, ${-dy / scale}px) scale(${s / scale})`,
        transformOrigin: "50% 100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      {label ? (
        <div
          style={{
            background: "rgba(35,20,8,0.8)",
            border: `2px solid ${GOLD}`,
            borderRadius: 24,
            padding: "10px 24px",
            marginBottom: 8,
            textAlign: "center",
            whiteSpace: "nowrap",
            color: CREAM,
            fontFamily: SANS,
            fontWeight: 600,
            fontSize: 30,
            boxShadow: "0 6px 24px rgba(0,0,0,0.45)",
          }}
        >
          {label}
          {sub ? (
            <div style={{ fontSize: 23, fontWeight: 400, color: GOLD, marginTop: 2 }}>{sub}</div>
          ) : null}
        </div>
      ) : null}
      {showPin ? (
        <div style={{ position: "relative" }}>
          <div
            style={{
              position: "absolute",
              left: "50%",
              bottom: -8,
              width: 40 + 60 * pulse,
              height: 14 + 20 * pulse,
              marginLeft: -(20 + 30 * pulse),
              borderRadius: "50%",
              border: `4px solid ${GOLD}`,
              opacity: 1 - pulse,
            }}
          />
          <svg width={64} height={86} viewBox="0 0 24 32" style={{ filter: "drop-shadow(0 4px 8px rgba(0,0,0,.5))" }}>
            <defs>
              <linearGradient id="pinGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stopColor="#FFE3A3" />
                <stop offset="1" stopColor="#C98F2B" />
              </linearGradient>
            </defs>
            <path d="M12 0C5.9 0 1 4.9 1 11c0 8 11 21 11 21s11-13 11-21C23 4.9 18.1 0 12 0z" fill="url(#pinGrad)" />
            <circle cx="12" cy="11" r="4.5" fill={CREAM} />
          </svg>
        </div>
      ) : null}
    </div>
  );
};

/* ---------- Karakter ---------- */
export type CharName = "male_batik" | "female" | "male_ihram";

export const CharSprite: React.FC<{
  name: CharName;
  at: Pt;
  scale: number;
  height?: number; // tinggi di layar (px)
  delay?: number;
  bob?: boolean;
}> = ({ name, at, scale, height = 440, delay = 0, bob = true }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame: frame - delay, fps, config: { damping: 11, stiffness: 140 } });
  const hop = bob ? Math.abs(Math.sin((frame + delay) * 0.18)) * 14 : 0;
  return (
    <div
      style={{
        position: "absolute",
        left: (at.x * W) / 100,
        top: (at.y * H) / 100,
        transform: `translate(-50%, -100%) translate(0px, ${-hop / scale}px) scale(${s})`,
        transformOrigin: "50% 100%",
        filter: "drop-shadow(0 10px 14px rgba(0,0,0,.45))",
      }}
    >
      <Img src={staticFile(`chars/${name}.png`)} style={{ height: height / scale, display: "block" }} />
    </div>
  );
};

/* ---------- Jalur perjalanan ---------- */
function geom(a: Pt, b: Pt, lift: number) {
  const ax = (a.x * W) / 100;
  const ay = (a.y * H) / 100;
  const bx = (b.x * W) / 100;
  const by = (b.y * H) / 100;
  const len = Math.hypot(bx - ax, by - ay);
  return { ax, ay, bx, by, cx: (ax + bx) / 2, cy: (ay + by) / 2 - lift * len };
}
function bez(g: ReturnType<typeof geom>, t: number): Pt {
  const u = 1 - t;
  return {
    x: ((u * u * g.ax + 2 * u * t * g.cx + t * t * g.bx) / W) * 100,
    y: ((u * u * g.ay + 2 * u * t * g.cy + t * t * g.by) / H) * 100,
  };
}

export const Route: React.FC<{
  a: Pt;
  b: Pt;
  progress: number; // 0..1
  scale: number;
  lift?: number;
  children?: (head: Pt) => React.ReactNode;
}> = ({ a, b, progress, scale, lift = 0.1, children }) => {
  const g = geom(a, b, lift);
  const d = `M ${g.ax} ${g.ay} Q ${g.cx} ${g.cy} ${g.bx} ${g.by}`;
  const head = bez(g, Math.min(1, Math.max(0, progress)));
  return (
    <>
      <svg
        width={W}
        height={H}
        style={{ position: "absolute", left: 0, top: 0, overflow: "visible", pointerEvents: "none" }}
      >
        <path
          d={d}
          fill="none"
          stroke="rgba(255,246,227,0.55)"
          strokeWidth={6 / scale}
          strokeLinecap="round"
          strokeDasharray={`${1 / scale} ${22 / scale}`}
        />
        <path
          d={d}
          fill="none"
          stroke={GOLD}
          strokeWidth={11 / scale}
          strokeLinecap="round"
          pathLength={1}
          strokeDasharray={`${progress} 2`}
          style={{ filter: "drop-shadow(0 0 10px rgba(255,190,80,0.95))" }}
        />
      </svg>
      {children ? children(head) : null}
    </>
  );
};

/* ---------- Teks & efek ---------- */
export const Shade: React.FC = () => (
  <div
    style={{
      position: "absolute",
      left: 0,
      right: 0,
      bottom: 0,
      height: 780,
      background: "linear-gradient(to top, rgba(25,12,4,0.78), rgba(25,12,4,0))",
    }}
  />
);

export const Caption: React.FC<{ title: string; sub?: string; delay?: number }> = ({
  title,
  sub,
  delay = 8,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { dur } = useScene();
  const s = spring({ frame: frame - delay, fps, config: { damping: 200 } });
  const out = interpolate(frame, [dur - 14, dur - 2], [1, 0], clamp);
  return (
    <div
      style={{
        position: "absolute",
        left: 60,
        right: 60,
        bottom: 300,
        textAlign: "center",
        opacity: s * out,
        transform: `translateY(${(1 - s) * 40}px)`,
      }}
    >
      <div
        style={{
          fontFamily: SERIF,
          fontWeight: 600,
          fontSize: 76,
          lineHeight: 1.1,
          color: CREAM,
          textShadow: "0 4px 22px rgba(0,0,0,0.75)",
        }}
      >
        {title}
      </div>
      {sub ? (
        <div
          style={{
            marginTop: 14,
            fontFamily: SANS,
            fontWeight: 400,
            fontSize: 38,
            lineHeight: 1.3,
            color: GOLD,
            textShadow: "0 3px 16px rgba(0,0,0,0.8)",
          }}
        >
          {sub}
        </div>
      ) : null}
    </div>
  );
};

const HEART =
  "M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z";

export const Hearts: React.FC<{ count?: number; seed?: string }> = ({ count = 9, seed = "h" }) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {Array.from({ length: count }).map((_, i) => {
        const x0 = random(`${seed}x${i}`) * (W - 140) + 40;
        const speed = 2.2 + random(`${seed}s${i}`) * 2.4;
        const off = random(`${seed}o${i}`) * 900;
        const size = 34 + random(`${seed}z${i}`) * 44;
        const travel = H + 240;
        const y = H + 80 - ((frame * speed + off) % travel);
        const sway = Math.sin((frame + off) * 0.05) * 30;
        const o = interpolate(y, [H * 0.1, H * 0.35, H], [0, 0.85, 0.85], clamp);
        return (
          <svg
            key={i}
            width={size}
            height={size}
            viewBox="0 0 24 24"
            style={{ position: "absolute", left: x0 + sway, top: y, opacity: o }}
          >
            <path d={HEART} fill={i % 2 ? "#FFB3C1" : GOLD} />
          </svg>
        );
      })}
    </AbsoluteFill>
  );
};

export const Sparkles: React.FC<{ count?: number; seed?: string }> = ({ count = 14, seed = "s" }) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {Array.from({ length: count }).map((_, i) => {
        const x = random(`${seed}x${i}`) * W;
        const y = random(`${seed}y${i}`) * H * 0.85;
        const size = 22 + random(`${seed}z${i}`) * 34;
        const tw = 0.5 + 0.5 * Math.sin(frame * 0.12 + random(`${seed}p${i}`) * 6.28);
        return (
          <svg
            key={i}
            width={size}
            height={size}
            viewBox="0 0 24 24"
            style={{ position: "absolute", left: x, top: y, opacity: tw * 0.9, transform: `scale(${0.5 + tw * 0.6})` }}
          >
            <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5Z" fill="#FFF3C9" />
          </svg>
        );
      })}
    </AbsoluteFill>
  );
};

/* ---------- Foto: tampil utuh, tanpa dipotong ---------- */
export const PhotoScene: React.FC<{
  src: string;
  w: number;
  h: number;
  title?: string;
  sub?: string;
  banner?: boolean;
  zoom?: boolean;
  hearts?: boolean;
}> = ({ src, w, h, title, sub, banner = false, zoom = true, hearts = true }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { dur } = useScene();
  const AREA_TOP = 270;
  const AREA_H = 1180;
  const MAX_W = 940;
  const k = Math.min(MAX_W / w, AREA_H / h);
  const bw = Math.round(w * k);
  const bh = Math.round(h * k);
  const enter = spring({ frame: frame - 4, fps, config: { damping: 18, stiffness: 90 } });
  const z = zoom ? interpolate(frame, [0, dur], [1, 1.035], clamp) : 1;
  return (
    <AbsoluteFill style={{ background: "#1a0f06", overflow: "hidden" }}>
      <Img
        src={staticFile(src)}
        style={{
          position: "absolute",
          inset: 0,
          width: W,
          height: H,
          objectFit: "cover",
          filter: "blur(40px) brightness(0.5) saturate(1.15)",
          transform: "scale(1.2)",
        }}
      />
      <AbsoluteFill
        style={{ background: "radial-gradient(ellipse at 50% 45%, rgba(244,207,134,0.22), rgba(20,10,4,0.55))" }}
      />
      <div
        style={{
          position: "absolute",
          left: (W - bw) / 2 - 10,
          top: AREA_TOP + (AREA_H - bh) / 2 - 10,
          width: bw,
          height: bh,
          border: `10px solid ${GOLD}`,
          borderRadius: 18,
          overflow: "hidden",
          boxShadow: "0 0 60px rgba(244,207,134,0.45), 0 20px 50px rgba(0,0,0,0.6)",
          opacity: enter,
          transform: `scale(${(0.92 + 0.08 * enter) * z})`,
        }}
      >
        <Img src={staticFile(src)} style={{ width: bw, height: bh, display: "block" }} />
      </div>
      {hearts ? <Hearts seed={src} count={8} /> : null}
      <Sparkles seed={`sp${src}`} count={8} />
      {banner ? <DateBanner /> : null}
      <Shade />
      {title ? <Caption title={title} sub={sub} /> : null}
    </AbsoluteFill>
  );
};

export const DateBanner: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame: frame - 6, fps, config: { damping: 14 } });
  return (
    <div
      style={{
        position: "absolute",
        top: 150,
        left: 0,
        right: 0,
        display: "flex",
        justifyContent: "center",
        opacity: s,
        transform: `translateY(${(1 - s) * -40}px) scale(${0.9 + 0.1 * s})`,
      }}
    >
      <div
        style={{
          background: "rgba(35,20,8,0.82)",
          border: `3px solid ${GOLD}`,
          borderRadius: 60,
          padding: "14px 44px",
          textAlign: "center",
          boxShadow: "0 8px 30px rgba(0,0,0,0.5)",
        }}
      >
        <div style={{ fontFamily: SANS, fontSize: 28, letterSpacing: 6, color: GOLD, textTransform: "uppercase" }}>
          Bertunangan
        </div>
        <div style={{ fontFamily: SERIF, fontWeight: 600, fontSize: 58, color: CREAM, marginTop: 2 }}>
          04 Juni 2026
        </div>
      </div>
    </div>
  );
};
