import React from "react";
import { AbsoluteFill, Img, OffthreadVideo, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig, Easing } from "remotion";
import { BROWN, CREAM, GLOBE, GOLD, H, INDO, JATIM, PHOTO, Pt, UNDANGAN_FILE, W } from "./config";
import {
  Caption,
  CharSprite,
  Hearts,
  MapPin,
  MapView,
  PhotoScene,
  Route,
  SANS,
  SERIF,
  Shade,
  Sparkles,
  useScene,
} from "./components/kit";

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
const easeIO = Easing.inOut(Easing.cubic);

/** Kemajuan jalur 0..1 antara dua titik waktu (dalam fraksi durasi adegan). */
function useProgress(from: number, to: number) {
  const frame = useCurrentFrame();
  const { dur } = useScene();
  return interpolate(frame, [from * dur, to * dur], [0, 1], { ...clamp, easing: easeIO });
}

/* ========== 1. AWAL CERITA — PROBOLINGGO ========== */
export const SceneGlobe: React.FC = () => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [8, 30, 100, 125], [0, 1, 1, 0], clamp);
  return (
    <AbsoluteFill>
      <MapView
        src="maps/globe.jpg"
        cams={[
          { t: 0, scale: 1, cx: 0.5, cy: 0.5 },
          { t: 1, scale: 2.3, cx: 0.67, cy: 0.55 },
        ]}
      />
      <div style={{ position: "absolute", top: 330, left: 0, right: 0, textAlign: "center", opacity: o }}>
        <div style={{ fontFamily: SERIF, fontWeight: 600, fontSize: 118, color: CREAM, textShadow: "0 6px 30px rgba(0,0,0,.8)" }}>
          Perjalanan Cinta
        </div>
        <div style={{ fontFamily: SANS, fontSize: 48, color: GOLD, marginTop: 10, letterSpacing: 4, textShadow: "0 4px 18px rgba(0,0,0,.8)" }}>
          Awang &amp; Rahma
        </div>
      </div>
    </AbsoluteFill>
  );
};

export const SceneIndonesiaZoom: React.FC = () => (
  <AbsoluteFill>
    <MapView
      src="maps/indonesia.jpg"
      cams={[
        { t: 0, scale: 1, cx: 0.5, cy: 0.5 },
        { t: 1, scale: 2.6, cx: 0.68, cy: 0.5 },
      ]}
    />
  </AbsoluteFill>
);

export const SceneProbolinggo: React.FC = () => (
  <AbsoluteFill>
    <MapView
      src="maps/probolinggo.jpg"
      cams={[
        { t: 0, scale: 1, cx: 0.5, cy: 0.5 },
        { t: 1, scale: 1.25, cx: 0.5, cy: 0.55 },
      ]}
    >
      {({ scale }) => (
        <>
          <MapPin at={{ x: 50, y: 45 }} scale={scale} showPin={false} label="Probolinggo" delay={14} dy={110} />
          <CharSprite name="male_batik" at={{ x: 24, y: 68 }} scale={scale} height={470} delay={24} />
        </>
      )}
    </MapView>
    <Shade />
    <Caption title="Awal Cerita" sub="PP Fadhilatut Tholibin, Probolinggo" />
  </AbsoluteFill>
);

/* ========== 2. MENUJU BOGOR ========== */
const CAM_ID_TO_BOGOR = [
  { t: 0, scale: 2.6, cx: 0.7, cy: 0.51 },
  { t: 0.38, scale: 1.15, cx: 0.48, cy: 0.45 },
  { t: 1, scale: 2.4, cx: 0.22, cy: 0.39 },
];
const CAM_ID_TO_EAST = [
  { t: 0, scale: 2.4, cx: 0.22, cy: 0.39 },
  { t: 0.38, scale: 1.15, cx: 0.48, cy: 0.45 },
  { t: 1, scale: 2.6, cx: 0.7, cy: 0.51 },
];

/** Perjalanan di peta Indonesia. `toBogor` = arah ke Bogor; `pair` = laki-laki + perempuan bersama. */
export const SceneIndoRoute: React.FC<{
  toBogor: boolean;
  pair: boolean;
  title: string;
  sub: string;
}> = ({ toBogor, pair, title, sub }) => {
  const p = useProgress(0.3, 0.9);
  const a = toBogor ? INDO.probolinggo : INDO.bogor;
  const b = toBogor ? INDO.bogor : INDO.probolinggo;
  return (
    <AbsoluteFill>
      <MapView src="maps/indonesia.jpg" cams={toBogor ? CAM_ID_TO_BOGOR : CAM_ID_TO_EAST}>
        {({ scale }) => (
          <>
            <MapPin at={INDO.probolinggo} scale={scale} label="Probolinggo" delay={4} />
            <MapPin at={INDO.bogor} scale={scale} label="Bogor" delay={4} />
            <Route a={a} b={b} progress={p} scale={scale} lift={0.04}>
              {(head: Pt) =>
                pair ? (
                  <>
                    <CharSprite name="male_batik" at={{ x: head.x - 1.6, y: head.y }} scale={scale} height={270} />
                    <CharSprite name="female" at={{ x: head.x + 1.6, y: head.y }} scale={scale} height={270} delay={3} />
                  </>
                ) : (
                  <CharSprite name="male_batik" at={head} scale={scale} height={300} />
                )
              }
            </Route>
          </>
        )}
      </MapView>
      <Shade />
      <Caption title={title} sub={sub} />
    </AbsoluteFill>
  );
};

export const SceneBogorPin: React.FC<{ pair: boolean; title: string; sub: string }> = ({ pair, title, sub }) => (
  <AbsoluteFill>
    <MapView
      src="maps/bogor-pin.jpg"
      cams={[
        { t: 0, scale: 1, cx: 0.5, cy: 0.5 },
        { t: 1, scale: 1.25, cx: 0.5, cy: 0.55 },
      ]}
    >
      {({ scale }) => (
        <>
          <MapPin at={{ x: 50, y: 45 }} scale={scale} showPin={false} label="Bogor" delay={14} dy={110} />
          {pair ? (
            <>
              <CharSprite name="male_batik" at={{ x: 20, y: 68 }} scale={scale} height={430} delay={22} />
              <CharSprite name="female" at={{ x: 34, y: 69 }} scale={scale} height={430} delay={28} />
            </>
          ) : (
            <CharSprite name="female" at={{ x: 24, y: 68 }} scale={scale} height={470} delay={24} />
          )}
        </>
      )}
    </MapView>
    <Shade />
    <Caption title={title} sub={sub} />
  </AbsoluteFill>
);

/* ========== 3. PERTUNANGAN ========== */
export const ScenePhoto: React.FC<{
  photo: { src: string; w: number; h: number };
  title?: string;
  sub?: string;
  banner?: boolean;
  zoom?: boolean;
}> = ({ photo, title, sub, banner, zoom }) => (
  <PhotoScene src={photo.src} w={photo.w} h={photo.h} title={title} sub={sub} banner={banner} zoom={zoom} />
);

/* ========== 4. MENUJU MAKKAH (GLOBE) ========== */
export const SceneGlobeToMakkah: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { dur } = useScene();
  const p = useProgress(0.15, 0.85);
  const arrive = spring({ frame: frame - dur * 0.85, fps, config: { damping: 12 } });
  return (
    <AbsoluteFill>
      <MapView
        src="maps/globe-makkah.jpg"
        cams={[
          { t: 0, scale: 1, cx: 0.5, cy: 0.5 },
          { t: 1, scale: 1.12, cx: 0.5, cy: 0.5 },
        ]}
      >
        {({ scale }) => (
          <>
            <MapPin at={{ x: GLOBE.bogor.x, y: GLOBE.bogor.y + 5 }} scale={scale} showPin={false} label="Bogor" delay={6} />
            <MapPin at={{ x: GLOBE.probolinggo.x - 2, y: GLOBE.probolinggo.y + 9 }} scale={scale} showPin={false} label="Probolinggo" delay={10} />
            <Route a={GLOBE.bogor} b={GLOBE.makkah} progress={p} scale={scale} lift={0.2}>
              {(h: Pt) => <CharSprite name="female" at={h} scale={scale} height={240} />}
            </Route>
            <Route a={GLOBE.probolinggo} b={GLOBE.makkah} progress={p} scale={scale} lift={0.3}>
              {(h: Pt) => <CharSprite name="male_ihram" at={h} scale={scale} height={240} delay={2} />}
            </Route>
            <MapPin at={{ x: GLOBE.makkah.x, y: GLOBE.makkah.y - 1 }} scale={scale} showPin={false} label="Makkah" delay={Math.round(dur * 0.85)} dy={90} />
            <div
              style={{
                position: "absolute",
                left: (GLOBE.makkah.x * W) / 100,
                top: (GLOBE.makkah.y * H) / 100,
                width: 150 / scale,
                height: 150 / scale,
                marginLeft: -75 / scale,
                marginTop: -75 / scale,
                borderRadius: "50%",
                border: `${5 / scale}px solid ${GOLD}`,
                opacity: arrive * (1 - ((frame % 45) / 45) * 0.8),
                transform: `scale(${0.4 + ((frame % 45) / 45) * 1.2})`,
              }}
            />
          </>
        )}
      </MapView>
      <Shade />
      <Caption title="Berangkat dari Tempat Masing-masing" sub="Bogor dan Probolinggo menuju Makkah" />
    </AbsoluteFill>
  );
};

/* ========== 5. AKAD DI MAKKAH ========== */
export const SceneMakkahMap: React.FC = () => (
  <AbsoluteFill>
    <MapView
      src="maps/makkah.jpg"
      cams={[
        { t: 0, scale: 1, cx: 0.5, cy: 0.5 },
        { t: 1, scale: 1.45, cx: 0.49, cy: 0.5 },
      ]}
    >
      {({ scale }) => (
        <>
          <MapPin at={{ x: 49, y: 40 }} scale={scale} showPin={false} label="Masjidil Haram" sub="Makkah" delay={12} />
          <CharSprite name="male_ihram" at={{ x: 22, y: 68 }} scale={scale} height={400} delay={22} />
          <CharSprite name="female" at={{ x: 76, y: 68 }} scale={scale} height={400} delay={28} />
        </>
      )}
    </MapView>
    <Hearts seed="mk" count={6} />
    <Shade />
    <Caption title="Masjidil Haram, Makkah" sub="Tempat akad nikah kami" />
  </AbsoluteFill>
);

export const SceneBukitVideo: React.FC = () => (
  <AbsoluteFill style={{ background: "#1a0f06" }}>
    <OffthreadVideo
      src={staticFile("video/bukit.mp4")}
      startFrom={45}
      volume={0.6}
      style={{ width: W, height: H, objectFit: "cover" }}
    />
    <Hearts seed="bk" count={7} />
    <Shade />
    <Caption title="Senja di Makkah" sub="Alhamdulillah" delay={20} />
  </AbsoluteFill>
);

/* ========== 6. PULANG KE BOGOR ========== */
export const SceneGlobeHome: React.FC = () => {
  const p = useProgress(0.12, 0.88);
  return (
    <AbsoluteFill>
      <MapView
        src="maps/globe-makkah.jpg"
        cams={[
          { t: 0, scale: 1.12, cx: 0.5, cy: 0.5 },
          { t: 1, scale: 1.0, cx: 0.5, cy: 0.5 },
        ]}
      >
        {({ scale }) => (
          <>
            <MapPin at={{ x: GLOBE.bogor.x, y: GLOBE.bogor.y + 5 }} scale={scale} showPin={false} label="Bogor" delay={6} />
            <Route a={GLOBE.makkah} b={GLOBE.bogor} progress={p} scale={scale} lift={0.2}>
              {(h: Pt) => (
                <>
                  <CharSprite name="male_ihram" at={{ x: h.x - 1.8, y: h.y }} scale={scale} height={240} />
                  <CharSprite name="female" at={{ x: h.x + 1.8, y: h.y }} scale={scale} height={240} delay={3} />
                </>
              )}
            </Route>
          </>
        )}
      </MapView>
      <Hearts seed="gh" count={6} />
      <Shade />
      <Caption title="Perjalanan Pulang" sub="Dari Makkah kembali ke Bogor" />
    </AbsoluteFill>
  );
};

export const SceneBogorHome: React.FC = () => (
  <AbsoluteFill>
    <MapView
      src="maps/bogor.jpg"
      cams={[
        { t: 0, scale: 1, cx: 0.5, cy: 0.5 },
        { t: 1, scale: 1.25, cx: 0.5, cy: 0.55 },
      ]}
    >
      {({ scale }) => (
        <>
          <CharSprite name="male_batik" at={{ x: 20, y: 68 }} scale={scale} height={430} delay={14} />
          <CharSprite name="female" at={{ x: 34, y: 69 }} scale={scale} height={430} delay={20} />
        </>
      )}
    </MapView>
    <Hearts seed="bh" count={6} />
    <Shade />
    <Caption title="Kembali ke Bogor" sub="Desa Cisarua, Kecamatan Nanggung" />
  </AbsoluteFill>
);

/* ========== 7. PERJALANAN MENGAJAR ========== */
export const SceneJatim: React.FC = () => {
  const p = useProgress(0.2, 0.85);
  return (
    <AbsoluteFill>
      <MapView
        src="maps/jatim.jpg"
        cams={[
          { t: 0, scale: 1, cx: 0.5, cy: 0.5 },
          { t: 1, scale: 1.7, cx: 0.52, cy: 0.46 },
        ]}
      >
        {({ scale }) => (
          <>
            <MapPin at={JATIM.probolinggo} scale={scale} label="PP Fadhilatut Tholibin" sub="Probolinggo" delay={6} />
            <MapPin at={JATIM.situbondo} scale={scale} label="PP Nurul Wafa" sub="Situbondo" delay={14} />
            <Route a={JATIM.probolinggo} b={JATIM.situbondo} progress={p} scale={scale} lift={0.12}>
              {(h: Pt) => (
                <>
                  <CharSprite name="male_batik" at={{ x: h.x - 1.4, y: h.y }} scale={scale} height={250} />
                  <CharSprite name="female" at={{ x: h.x + 1.4, y: h.y }} scale={scale} height={250} delay={3} />
                </>
              )}
            </Route>
          </>
        )}
      </MapView>
      <Shade />
      <Caption title="Mengajar Bersama" sub="Probolinggo dan Situbondo" />
    </AbsoluteFill>
  );
};

/* ========== 9. RESEPSI ========== */
export const SceneResepsi: React.FC = () => (
  <AbsoluteFill>
    <MapView
      src="maps/resepsi.jpg"
      cams={[
        { t: 0, scale: 1, cx: 0.5, cy: 0.5 },
        { t: 1, scale: 1.35, cx: 0.55, cy: 0.58 },
      ]}
    >
      {({ scale }) => (
        <>
          <CharSprite name="male_batik" at={{ x: 43, y: 74 }} scale={scale} height={400} delay={16} />
          <CharSprite name="female" at={{ x: 56, y: 75 }} scale={scale} height={400} delay={22} />
        </>
      )}
    </MapView>
    <Sparkles seed="rs" count={16} />
    <Hearts seed="rs" count={8} />
    <Shade />
    <Caption title="Menuju Resepsi" sub="Awang &amp; Rahma" />
  </AbsoluteFill>
);

/* ========== 10. TRANSISI KE UNDANGAN ========== */
export const SceneUndangan: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame: frame - 6, fps, config: { damping: 20, stiffness: 80 } });
  const glow = 0.55 + 0.25 * Math.sin(frame * 0.08);
  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(circle at 50% 42%, rgba(244,207,134,${glow * 0.55}), ${BROWN} 62%, #120a04 100%)`,
      }}
    >
      <Sparkles seed="un" count={22} />
      {UNDANGAN_FILE ? (
        <div
          style={{
            position: "absolute",
            left: 90,
            right: 90,
            top: 220,
            bottom: 300,
            borderRadius: 36,
            border: `8px solid ${GOLD}`,
            overflow: "hidden",
            boxShadow: "0 0 80px rgba(244,207,134,.5)",
            opacity: s,
            transform: `scale(${0.85 + 0.15 * s})`,
          }}
        >
          <Img src={staticFile(UNDANGAN_FILE)} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </div>
      ) : (
        <div style={{ position: "absolute", left: 0, right: 0, top: 640, textAlign: "center", opacity: s, transform: `scale(${0.9 + 0.1 * s})` }}>
          <div style={{ fontFamily: SANS, fontSize: 36, letterSpacing: 10, color: GOLD, textTransform: "uppercase" }}>
            Undangan Pernikahan
          </div>
          <div style={{ fontFamily: SERIF, fontWeight: 600, fontSize: 132, lineHeight: 1.1, color: CREAM, marginTop: 30, textShadow: "0 6px 30px rgba(0,0,0,.6)" }}>
            Awang
            <br />&amp;
            <br />
            Rahma
          </div>
        </div>
      )}
      <Hearts seed="un" count={8} />
    </AbsoluteFill>
  );
};
