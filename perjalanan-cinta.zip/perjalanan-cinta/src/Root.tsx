import React from "react";
import { Composition } from "remotion";
import { FPS, H, W } from "./config";
import { PerjalananCinta } from "./PerjalananCinta";
import { TOTAL_FRAMES } from "./timeline";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="PerjalananCinta"
    component={PerjalananCinta}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={W}
    height={H}
  />
);
