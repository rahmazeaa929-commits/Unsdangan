import React from "react";
import { AbsoluteFill, Audio, interpolate, staticFile } from "remotion";
import { MUSIC_FILE, OVERLAP } from "./config";
import { Scene } from "./components/kit";
import { SCENES, TOTAL_FRAMES } from "./timeline";

const STARTS = SCENES.reduce<number[]>((acc, s, i) => {
  acc.push(i === 0 ? 0 : acc[i - 1] + SCENES[i - 1].dur - OVERLAP);
  return acc;
}, []);

export const PerjalananCinta: React.FC = () => (
  <AbsoluteFill style={{ background: "#120a04" }}>
    {SCENES.map((s, i) => (
      <Scene key={s.name} from={STARTS[i]} dur={s.dur}>
        {s.el}
      </Scene>
    ))}
    {MUSIC_FILE ? (
      <Audio
        src={staticFile(MUSIC_FILE)}
        volume={(f) => interpolate(f, [TOTAL_FRAMES - 60, TOTAL_FRAMES], [0.9, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })}
      />
    ) : null}
  </AbsoluteFill>
);
