// ====== PENGATURAN UTAMA ======
export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const OVERLAP = 15; // frame tumpang tindih antar adegan (cross-dissolve)
export const sec = (s: number) => Math.round(s * FPS);

// Opsional: taruh file di folder public/ lalu isi namanya di sini.
export const MUSIC_FILE: string | null = null; // contoh: "music.mp3"
export const UNDANGAN_FILE: string | null = null; // contoh: "undangan.jpg" (tangkapan layar undangan)

export const GOLD = "#F4CF86";
export const CREAM = "#FFF6E3";
export const BROWN = "#2B1A0C";

export type Pt = { x: number; y: number };

// Koordinat dalam PERSEN dari gambar peta (x dari kiri, y dari atas).
export const INDO = {
  probolinggo: { x: 70, y: 51 },
  bogor: { x: 20, y: 39 },
};
export const JATIM = {
  probolinggo: { x: 44, y: 39 },
  situbondo: { x: 63, y: 47 },
};
export const GLOBE = {
  makkah: { x: 16.5, y: 41 },
  bogor: { x: 80.8, y: 57.5 },
  probolinggo: { x: 89.6, y: 57.8 },
};

// Ukuran asli foto (agar tampil utuh, tidak dipotong).
export const PHOTO = {
  tunanganBerdua: { src: "photos/tunangan-berdua.jpg", w: 1237, h: 2200 },
  tunanganCincinDuduk: { src: "photos/tunangan-cincin-duduk.jpg", w: 1500, h: 2000 },
  tunanganPasangCincin: { src: "photos/tunangan-pasang-cincin.jpg", w: 1500, h: 2000 },
  tunanganKeluarga: { src: "photos/tunangan-keluarga.jpg", w: 900, h: 1195 },
  makkahBerdua: { src: "photos/makkah-berdua.jpg", w: 900, h: 1600 },
  akad: { src: "photos/akad-makkah.jpg", w: 1500, h: 1125 },
  makkahRombongan: { src: "photos/makkah-rombongan.jpg", w: 1500, h: 1996 },
};
